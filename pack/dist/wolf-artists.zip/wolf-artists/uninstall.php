<?php
/**
 * Wolf Artists Uninstall
 *
 * Uninstalling Wolf Artists
 *
 * @author WolfThemes
 * @category Core
 * @package WolfArtists/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}