Thanks for downloading Wolf Artists!

A label plugin to sort your artists

Plugin page:
http://wolfthemes.com/plugin/wolf-artists

Being a free product, this plugin is distributed as-is without official support.
Verified customers however, who have purchased a premium theme
at http://themeforest.net/user/Wolf-Themes/portfolio?ref=Wolf-Themes
will have access to support for this plugin in the forums
http://wlfthm.es/help

Have fun!